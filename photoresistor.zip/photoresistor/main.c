#include <avr/io.h>
#include <util/delay.h>
#include "adc.h"
#include "servo.h"
#include "foto.h"  // Zahrnutí fotorezistoru

int main(void) {
    uint8_t current_angle = 90;  // Servo začne uprostřed
    uint16_t light_intensity = 0;  // Hodnota z fotorezistoru

    // Inicializace ADC, serva a fotorezistoru
    adc_init();
    servo_init();
    fotorezistor_init();  // Inicializace fotorezistoru

    // Nastavení serva na počáteční úhel (90°)
    servo_set_angle(current_angle);

    while (1) {
        // Čtení intenzity světla z fotorezistoru
        light_intensity = fotorezistor_read();  // Používáme fotorezistor pro čtení hodnoty

        // Ovládání serva podle fotorezistoru
        if (light_intensity > 512) {
            current_angle = 180;  // Světlo je silné, servo nastavíme na 180°
        } else {
            current_angle = 0;  // Světlo je slabé, servo nastavíme na 0°
        }

        servo_set_angle(current_angle);  // Nastavíme servo na vypočtený úhel

        // Zpoždění mezi cykly
        _delay_ms(100);
    }

    return 0;
}