#include "foto.h"
#include "adc.h"

// Inicializace fotorezistoru (ADC)
void fotorezistor_init(void) {
    adc_init();  // Inicializace ADC pro čtení fotorezistoru
}

// Funkce pro čtení hodnoty z fotorezistoru (LDR)
uint16_t fotorezistor_read(void) {
    return adc_read(LDR_PIN);  // Čte hodnotu z fotorezistoru (ADC)
}