#ifndef FOTOREZISTOR_H
#define FOTOREZISTOR_H

#include <avr/io.h>

// Definice pinu pro fotorezistor (LDR)
#define LDR_PIN 0  // Fotorezistor na kanálu ADC0 (A0)

// Funkce pro inicializaci ADC
void fotorezistor_init(void);

// Funkce pro čtení hodnoty z fotorezistoru (LDR)
uint16_t fotorezistor_read(void);

#endif // FOTOREZISTOR_H